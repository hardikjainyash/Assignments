package springfirstapp;
import springfirstapp.Employee;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("Welcome");
   //Using Bean Factory as a IOC Container
   Resource res= new ClassPathResource("applicationcontext.xml");
   BeanFactory fac=new XmlBeanFactory(res);
		Employee e=(Employee) fac.getBean("employee");
		System.out.println(e);
		Employee e1=(Employee) fac.getBean("employee1");
		System.out.print(e1);
	}

}
