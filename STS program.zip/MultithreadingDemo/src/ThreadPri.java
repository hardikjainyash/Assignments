
public class ThreadPri extends Thread
{
	
	public void run()
	{
		System.out.println("In Run Method");
		System.out.println(Thread.currentThread().getPriority());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(MIN_PRIORITY);
		System.out.println(Thread.currentThread().getPriority());
		ThreadPri tp = new ThreadPri();
		tp.setPriority(MAX_PRIORITY);
		tp.start();
	}

}
