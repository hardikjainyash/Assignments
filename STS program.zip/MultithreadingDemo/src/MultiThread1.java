
 class MyThread1 extends Thread {

	public void run()
	{
		System.out.println("In Thread1");
		
	}
	
	
 }

 class MyThread2 extends Thread {

	public void run()
	{
		System.out.println("In Thread2");
		
	}
	
	
 }
 
 class MyThread3 extends Thread {

	public void run()
	{
		System.out.println("In Thread3");
		
	}
	
	
 }
 
 
 
 
 public class MultiThread1 
 {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
          MyThread1 mt1 = new MyThread1();
          mt1.start();
          MyThread2 mt2 = new MyThread2();
          mt2.start();
          MyThread3 mt3 = new MyThread3();
          mt3.start();
         
	}
	
 }


