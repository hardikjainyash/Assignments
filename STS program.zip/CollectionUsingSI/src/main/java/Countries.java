import java.util.*;
public class Countries {
  private List li;
  private Map <Integer,String> map;
public List getLi() {
	return li;
}
@Override
public String toString() {
	return "Countries [li=" + li + ", map=" + map + "]";
}
public void setLi(List li) {
	this.li = li;
}
public Map<Integer, String> getMap() {
	return map;
}
public void setMap(Map<Integer, String> map) {
	this.map = map;
}
  
	
	
	
	
	
}
