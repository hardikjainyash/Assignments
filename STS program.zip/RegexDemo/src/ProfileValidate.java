import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProfileValidate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pattern p =Pattern.compile("[0-9]{10}");
		Matcher m =p.matcher("9826672724");
		if(m.find())
			System.out.println("Correct num");
		else
			System.out.println("Incorrect Num");
		Pattern p1 = Pattern.compile("^https:");
		Matcher m1=p1.matcher("https://aaah.org");
		if(m1.find())
			System.out.println("Correct url");
		else
			System.out.println("Incorrect Url");
		Pattern p2=Pattern.compile(".+@.+\\..+");
		Matcher m2 =p2.matcher("hardik.yash@com");
		if(m2.find())
			System.out.println("Correct Email");
		else 
			System.out.println("In correct Email");
	}

}
