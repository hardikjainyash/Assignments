
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;

class Test
{   private String s;
    public Test()  
    {  
    	this.s = "Hardik";
    }
    
  public void method1()  {
        System.out.println("The string is " + s);
    }
    
}  
public class Reflection {

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		//Test t=new Test();
		Class cls = Class.forName("Test");
		System.out.println("The name of class is:"+cls.getName());
		Constructor c =cls.getConstructor();
		System.out.println(c.getName());
   	}

}
