
public class WatchPoint {

	public static void main(String[] args) {
	
		int a =9;
	 for(int i=0;i<2;i++)
		a++;
	 if(a>10)
	 System.out.println(a);
     a++;
     System.out.println(a);
	}

}
