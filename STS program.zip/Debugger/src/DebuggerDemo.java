
public class DebuggerDemo {

	public static void main(String[] args) {
		System.out.println("Welcome in sts");
		System.out.println("Again");
	}
	
}
