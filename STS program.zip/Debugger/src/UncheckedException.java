import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.ArithmeticException;
import java.lang.NullPointerException;
import java.lang.ClassCastException;
import java.lang.IllegalArgumentException;
import java.util.InputMismatchException;
public class UncheckedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try {
        	int c;
        	c=10/0;
		String s =null;
		s.charAt(12);
		String s1= "YASH";
		System.out.println(s1.charAt(5));
		Object o= new Object();
		String so=(String) o;
	}
     catch(NullPointerException np)
     {
    	 
       System.out.println(np); 	 
      }
      catch(ArrayIndexOutOfBoundsException arr)
        {
    	  System.out.println(arr.getMessage());
        }
        catch(ArithmeticException ae)
        {
        	ae.printStackTrace();
        }
        catch(InputMismatchException inp)
        {
        	System.out.println(inp);
        }
        catch(IllegalArgumentException iae)
        {
        	System.out.println(iae);
        }
      
	}
}
