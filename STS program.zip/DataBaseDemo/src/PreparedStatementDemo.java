
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class PreparedStatementDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    try {
		Class.forName("com.mysql.jdbc.Driver");

		String url ="jdbc:mysql://localhost:3306/hardik";
		String user="root";
		String pass="root";

		Connection con =DriverManager.getConnection(url,user,pass);
		if(con!=null)
		System.out.println("Connection is Created");
		else
		System.out.println("Connection is Not Created");
		
		PreparedStatement st=con.prepareStatement("insert into employee(empId,name) values(?,?)");  
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	     System.out.println("Enter ID");
		int id =Integer.parseInt(br.readLine());
		System.out.println("Enter Name");
		String name =br.readLine();
		st.setInt(1,id);//1 specifies the first parameter in the query  
		st.setString(2,name);  
		  
		int i=st.executeUpdate();  
		System.out.println(i+" records inserted");  
		
		
		String SQL = "update employee set name = ? WHERE empId = ?";
		 PreparedStatement ps = con.prepareStatement(SQL);
		 
		ps.setString(1,"Jaduu");
		ps.setInt(2,1001);
		int n =ps.executeUpdate();
		System.out.println(n);
		PreparedStatement stmt=con.prepareStatement("delete from employee where empId=?");  
		stmt.setInt(1,1001);  
		  
		int n1=stmt.executeUpdate();  
		System.out.println(n1+" records deleted");  
		
		con.close();
		//s.close();
    }
    catch(Exception e )
    {
    	System.out.println(e);
    }
		
	}

}
