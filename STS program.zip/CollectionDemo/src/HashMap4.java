import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMap4 {

	Map<String,String> M1 = new HashMap<String,String>();
	
	public Map<String,String> saveCountryCapital(String CountryName,String Capital)
	{
		M1.put(CountryName, Capital);
		return M1;
	}
	
	public Object getCountry(String CapitalName)
	{
		for(Map.Entry m : M1.entrySet())
		{
			if(CapitalName.equals(m.getValue()))
			{
	           return m.getKey();        			
			}
		}
		return null;
		
		
	}
	public String getCapital(String CountryName) 
	{
		return M1.get(CountryName);
	}
	
	public Map<String,String> excahngeKeyValue()
	{
		Map<String,String> M2 = new HashMap<String,String>();
		
		for(Map.Entry m : M1.entrySet())
		{
			System.out.println("Key is "+m.getKey()+" Value is "+m.getValue());
			M2.put((String)m.getValue(),(String)m.getKey());
		}
		return M2;
		
	}
	
	public List createArrayList()
	{
		List<String> li = new ArrayList<String>();
		System.out.println("In ArrayList");
		for(Map.Entry m : M1.entrySet())
		{
			System.out.println("Key is "+m.getKey()+" Value is "+m.getValue());
			li.add((String)m.getKey());
		}
		
		return li;
	}
}
