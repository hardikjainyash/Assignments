import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class HashMap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Map<Integer,String> map = new HashMap<Integer,String>();
       map.put(104, "Hardik");
       map.put(103, "Jaynam");
       map.put(102, "Tanu");
      
       Scanner s = new Scanner(System.in);
        
       System.out.println("Enter the key");
       int key=s.nextInt();
       
       if(map.containsKey(key))
    	   System.out.println("Key is present");
       else
    	   System.out.println("Not Present");
       System.out.println("Enter the value");
       String str=s.next();
       if(map.containsValue(str))
    	   System.out.println("Value is present");
       else 
    	   System.out.println("Not Present");
       
       for(Entry<Integer, String> m : map.entrySet())
    	   System.out.println("Key "+m.getKey()+"Value is "+m.getValue());
    	  
       
       
	}

}
