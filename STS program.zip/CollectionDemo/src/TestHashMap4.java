import java.util.List;
import java.util.Map;

public class TestHashMap4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     HashMap4 hm4 = new HashMap4();
     hm4.saveCountryCapital("India","Delhi");
     hm4.saveCountryCapital("Japan","Tokyo");
      System.out.println(hm4.getCountry("Delhi"));
      System.out.println(hm4.getCapital("Japan"));
      System.out.println("Orginal Hashmap is:");
       Map<String,String> MapRe=hm4.excahngeKeyValue();
       System.out.println("After reversing Hashmap is:");
       for(Map.Entry m :MapRe.entrySet())
       {
    	   System.out.println("Key is "+m.getKey()+" Value is "+m.getValue());
       }
       List<String> li = hm4.createArrayList();
       System.out.println(li);
     
	}

}
