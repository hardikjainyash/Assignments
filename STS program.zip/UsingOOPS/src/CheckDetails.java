
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.*;

public class CheckDetails extends Details
{
   private double amt,depositamt;
    String acc;
   Scanner s = new Scanner(System.in);
   Details d = new Details();
  

public void showBal()
{    
	System.out.println("Current Balance is:"+d.currentbal);
	System.out.println("");
}   


public void deposit() throws Exception

{
    	 
	 double localbal=d.currentbal;
	 	
	System.out.println("Enter the amount you want to deposit ");
    this.depositamt=s.nextDouble();

	
	localbal=localbal+this.depositamt;
	
	System.out.println("Money is deposit in your Account");
	System.out.println("Current Balance is:"+localbal);
	System.out.println("");


}
   
public boolean checkUser(String user,String pass)
{   String s="admin";
if(s.equals(user) && s.equals(pass))   
 return true;
else
 return false; 
 
}


public boolean checkUser(int acc, String ifsc)
{    
      
	  if(acc==super.accno && ifsc.equals(super.ifsc))
		  return true;
	  else 
		  return false;
	
	
}



public void transferMoney() throws Exception
{  
      
    double bal =super.currentbal;
    int accno;String ifsc;
	
	 
		
        do{
		System.out.println("Enter Account Number");
		accno=s.nextInt();
		System.out.println("Enter IFSC");
		ifsc=s.next();
		if(!this.checkUser(accno,ifsc))
		{ System.out.println("");	
		  System.out.println("Enter Correct Detail");
		 
		}
		else
		{
		 System.out.println("Enter the amount for transfer");
         this.amt=s.nextDouble();
	     if(this.amt>bal)
		  System.out.println("Balance is Insufficient");
	     else
		 {  super.currentbal=bal-this.amt;
	        
	 
	 
	        System.out.println("Money is transferred");	
            System.out.println("Remaining Balance is"+super.currentbal);	 
			 
			 
		 }
	    }
		}while(!this.checkUser(accno,ifsc));
		
		
		
		
      
	   System.out.println("");	   
	
	
}

public void editProfile()
{
	System.out.println("Your Profile Details :");
	System.out.println("Your Name is: "+super.accname);
	System.out.println("Your Address is: "+super.address);
	System.out.println("Your Mobile no. is:"+super.mobileno);
	System.out.println("");
	System.out.println("Enter your new name:");
	super.accname=s.nextLine();

	Pattern p =Pattern.compile("[0-9]");
	Matcher m =p.matcher(super.accname);
	if(m.find())
	{
		System.out.println("Enter Correct Name");
		super.accname=s.nextLine();
	}
	
		System.out.println("Enter your new Address:");
	super.address=s.nextLine();
	 p =Pattern.compile(" ");
	 m =p.matcher(super.address);
	if(m.find())
	{	System.out.println("InCorrect Address");
	    System.out.println("Please Enter Correct Address");
	    super.address=s.next();
	}
	
	
	System.out.println("Enter your new Mobile Number:");
	super.mobileno=s.next();
	
	 p =Pattern.compile("[0-9] {10}");
	 m =p.matcher(super.mobileno);
	if(!m.find())
	{	System.out.println("InCorrect Number");
	    System.out.println("Please Enter Correct Number");
	    super.mobileno=s.next();
	}
	
	System.out.println("");
	System.out.println("Your Updated deatils is-:");
	System.out.println("Name is: "+super.accname);
	System.out.println("Address is: "+super.address);
	System.out.println("Mobile no.is:"+super.mobileno);
	System.out.println("");
	
	
	
}





}



