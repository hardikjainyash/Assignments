import java.util.Scanner;
import java.io.*;
public class LoginDetails extends CheckDetails
{

public static void main(String[] args)
{
  String user;
  String pass;
int choice;
char[] ch;
Console con=System.console();
CheckDetails cd = new CheckDetails();
Scanner sc= new Scanner(System.in);
do{
System.out.println("Enter Your Username");

user=sc.next();
System.out.println("Enter Your Password");
ch=con.readPassword();
pass=String.valueOf(ch);

if(!cd.checkUser(user,pass))
{   System.out.println("");
    System.out.println("Please Enter the Correct Data");
	 
}
	
}while(!cd.checkUser(user,pass));
 
 
   System.out.println("Login Successful");
   System.out.println("");
   try{
   do
   { System.out.println("********* PAYMENT MENU *********");
   System.out.println("1.Transfer Money");
   System.out.println("2.Check Balance");
   System.out.println("3.Deposit Money");
   System.out.println("4.Edit Profile");
   System.out.println("5.Exit");
   System.out.print("Enter your Choice:-");
   choice=sc.nextInt();
   
    switch(choice)
   {
	   case 1 : cd.transferMoney();break;
	   case 2 : cd.showBal();break;
	   case 3 : cd.deposit();break;
	   case 4 : cd.editProfile();break;
	   case 5 : System.exit(0);
	   default : System.out.println("Invalid Choice Please Enter Correct Choice");
	   
	   
	   
   }
   
   }while(choice!=5);
   
   }
   catch(Exception e)
   {
	   System.out.println(e);
   }
   
 sc.close();
 
}


}
