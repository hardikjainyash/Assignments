

 public class Details
{
 double currentbal=50000;
 int accno;
String accname="Hardik Jain";
 String ifsc="hard09";
 String address="Indore";
 String mobileno="9753937379";





  
  
}
