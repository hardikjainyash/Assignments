class A
{
 String Name ;
 A(String Name){
	 this.Name= Name;
	 
 }

}

class SuperDemo extends A
{
  //SuperDemo()
  //{
	//  super("Hardik");
	  
  //}
	void display(String last)
  { System.out.println(Name+last); 
   
  }
 public static void main(String[] args) 
  {
  
  SuperDemo sd = new SuperDemo("Hardik");
  sd.display("Jain");
  
  
  
  }
  
  
}