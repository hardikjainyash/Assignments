class Outer
{
	
	static int a=10;
static class Inner
{
void show()
{
System.out.println("In Inner show"+a);
}

}


}

public class OuterDemo2
{
public static void main(String[] args)
{
     Outer.Inner oi = new Outer.Inner();
   oi.show();



}

}