static class Outer
{
static class Inner
{
void show()
{
System.out.println("In Inner show");
}

}


}

public class OuterDemo2
{
public static void main(String[] args)
{
   
    
   Outer.show();


}

}