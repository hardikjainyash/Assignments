class Outer
{
class Inner
{
void show()
{
System.out.println("In Inner show");
}

}


}

public class OuterDemo
{
public static void main(String[] args)
{
   Outer o= new Outer();
   Outer.Inner oi=o.new Inner();
   
  // Inner oi = new Inner();
   oi.show();


}

}