class Palindrome{
public static void main(String args[])
{
String s=args[0];
int f=0;
int len=s.length();
for(int i=0;i<len;i++)
{
	if(s.charAt(i)==s.charAt(len-i-1))
		continue;
	else 
		f=1;
     	
	
}
if(f==0)
	System.out.println("palindrome");
else
	System.out.println("Not");

}


}