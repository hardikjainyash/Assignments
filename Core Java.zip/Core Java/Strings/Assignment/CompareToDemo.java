class CompareToDemo{
public static void main(String args[])
{
String s="  Cat is a pet";
String s1="Dog";
System.out.println(s.compareTo(s1));
System.out.println(s.isEmpty());
System.out.println(s.equalsIgnoreCase(s1));//Compares this String to another String, ignoring case considerations.
//s=s.trim;
System.out.println(s.trim());
System.out.println(s.substring(4));


}



}