class StringBuilderDemo{
public static void main(String args[])
{
StringBuilder sb = new StringBuilder("Hardik");
sb.append("Hello");
System.out.println(sb);




}



}