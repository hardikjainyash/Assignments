class EvenLength{
public static void main(String args[])
{

String s= args[0];
int len =s.length();
if(len%2!=0)
 System.out.println("Null");
 else 
  System.out.println(s.substring(0,len/2));


}



}