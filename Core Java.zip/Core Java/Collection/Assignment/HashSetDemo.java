import java.util.HashSet;   

class HashSetDemo
{

public static void main(String[] args)
{
 
HashSet<Integer> mylist = new HashSet<Integer>();
System.out.println(mylist.add(10));
System.out.println(mylist.add(20));
System.out.println(mylist.add(30));
System.out.println(mylist.add(10));

System.out.println(mylist);
//HashSet<Character> ml = new HashSet<Character>();
//ml.add('h');
//System.out.println(ml);
for(Integer i : mylist)
System.out.println("In foreach"+i);
}


}