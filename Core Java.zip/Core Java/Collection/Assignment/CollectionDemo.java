import java.util.ArrayList;
import java.util.Iterator;

class CollectionDemo
{

public static void main(String[] args)
{

ArrayList<String> a1 = new ArrayList<String>();
a1.add("January");
a1.add("February");
a1.add("March");
a1.add("April");
a1.add("May");
a1.add("June");
a1.add("July");
a1.add("August");
a1.add("September");
a1.add("October");
a1.add("November");
a1.add("December");

System.out.println("Printing Direct Object:");
System.out.println(a1);
Iterator i=a1.iterator();
while(i.hasNext())
System.out.println(i.next());
for(String j:a1)
 System.out.println("In ForEach"+j);

}



}