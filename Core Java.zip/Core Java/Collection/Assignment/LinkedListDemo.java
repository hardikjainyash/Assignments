import java.util.LinkedList;
import java.util.ListIterator;
class LinkedListDemo
{

public static void main(String[] args)
{

LinkedList<Integer> ll = new LinkedList<Integer>();
ll.add(10);
ll.add(20);
ll.add(30);
ll.add(20);
System.out.println(ll);

ListIterator li = ll.listIterator();

while(li.hasNext())
	li.next();
System.out.println("In reverse");
while(li.hasPrevious())
 System.out.println(li.previous());
}

}