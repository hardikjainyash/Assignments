import java.util.Vector;
class VectorDemo1
{
public static void main(String[] args)
{
Vector<String> v1 = new Vector<String>();
v1.add("January");
v1.add("February");
v1.add("March");
v1.add("April");
v1.add("May");
v1.add("June");
v1.add("July");
v1.add("August");
v1.add("September");
v1.add("October");
v1.add("November");
v1.add("December");


for(String i : v1)
System.out.println("In foreach"+i);

}
}