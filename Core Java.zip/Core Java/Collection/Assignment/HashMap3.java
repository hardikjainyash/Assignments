import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class HashMap3 {

	public static void main(String[] args) {
		 Map<String,Integer> ContactList = new HashMap<String,Integer>();
		   
	       ContactList.put("Hardik",102);
	       ContactList.put("Jaynam",107);
	       ContactList.put("Tanu",109);
	       Scanner s = new Scanner(System.in);
	        
	       System.out.println("Enter the key");
	       String key=s.next();
	       
	       
	       
	       if(ContactList.containsKey(key))
	    	   System.out.println("Key is present");
	       else
	    	   System.out.println("Not Present");
	       System.out.println("Enter the value");
	       int value=s.nextInt();
	       if(ContactList.containsValue(value))
	    	   System.out.println("Value is present");
	       else 
	    	   System.out.println("Not Present");
	       
	       for(Map.Entry m : ContactList.entrySet())
	    	   System.out.println("Key "+m.getKey()+"Value is "+m.getValue());
	    	  
	       
		 
		
	}
	
}
