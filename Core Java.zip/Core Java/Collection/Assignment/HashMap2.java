import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;


public class HashMap2 {

public static void main(String args[]) {
	 
	Properties p = new Properties();
	
	p.put("Bhopal","M.P.");
	p.put("Jaipur","Rajasthan");
	p.put("Lucknow","U.P");
	Set s = p.entrySet();
	Iterator i =s.iterator();
	while(i.hasNext())
	{
		Map.Entry entry = (Map.Entry)i.next();
		System.out.println("Key is "+entry.getKey()+" Value is "+entry.getValue());
		
	}
	
	
	

}

}

