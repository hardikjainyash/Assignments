import java.util.Map;
import java.util.ListIterator;
import java.util.HashMap;
import java.util.TreeMap;

class MapDemo
{

public static void main(String[] args)
{

Map<Integer,String> unsortMap = new HashMap<Integer,String>();

unsortMap.put(112,"Abc");
unsortMap.put(100,"Bca");
unsortMap.put(190,"zsa");
unsortMap.put(13,"za");





System.out.println("Unsort Map......");
        printMap(unsortMap);

        System.out.println("\nSorted Map......By Key");
        Map<Integer, String> treeMap = new TreeMap<Integer, String>(unsortMap);
        printMap(treeMap);

    }

    
    public static <Integer,String> void printMap(Map<Integer, String> map) {
        for (Map.Entry entry : map.entrySet()) {
            System.out.println("Key : " + entry.getKey() 
				+ " Value : " + entry.getValue());
        }
		
	}
	
	
}