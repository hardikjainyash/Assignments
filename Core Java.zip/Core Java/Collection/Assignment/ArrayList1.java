import java.util.ArrayList;

class ArrayList1
{

public static void main(String[] args)
{

ArrayList<Integer> list = new ArrayList<Integer>();
int a=10;
list.add(a);
//list.add(13.34);
System.out.print(list);

}


}