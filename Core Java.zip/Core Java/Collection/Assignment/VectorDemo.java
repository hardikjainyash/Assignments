import java.util.Vector;
class VectorDemo
{
public static void main(String[] args)
{
Vector<Integer> ve = new Vector<Integer>();
ve.add(10);
ve.add(80);
ve.add(50);
ve.add(40);
System.out.println(ve);
for(Integer i : ve)
System.out.println("In foreach"+i);

}
}