import java.util.ArrayList;
import java.util.Scanner;
public class ArrayList2 {

	public static void addNumber(int a)
	{
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(a);
		System.out.println(al);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the Number");
		int a =s.nextInt();
		//double d =s.nextDouble();
		//float f=s.nextFloat();
		ArrayList2.addNumber(a);
		
	}
	
}
