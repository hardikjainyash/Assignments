import java.io.*;

class Employee1 implements Serializable // by setter getter
{
private String name;
private String department;
private String designation;
private double salary;

public void setName(String name)
{
  this.name=name;

}
public void setDepartment(String department)
{
  this.department=department;

}
public void setDesignation(String designation)
{
  this.designation=designation;

}
public void setSalary(double salary)
{
	this.salary=salary;
}

String getName()
{
 return name;

}

String getDepartment()
{
 return department;
}

String getDesignation()
{
 return designation;
}

double getSalary()
{
	return salary;
	
}

}