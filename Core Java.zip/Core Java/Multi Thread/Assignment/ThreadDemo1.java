
public class ThreadDemo1 extends Thread {//Making a thread by using Thread Class

	public void run()
	{
		System.out.println("Thread Start");
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		ThreadDemo1 t1 = new ThreadDemo1();
		t1.start();
	}

}
