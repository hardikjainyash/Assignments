
public class ThreadDemo2 implements Runnable  {

	
	public void run() {
		// TODO Auto-generated method stub
	System.out.println("Thread Start");
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo2 t2 = new ThreadDemo2();
		Thread t = new Thread(t2);
		t.start();
	}
	

}
