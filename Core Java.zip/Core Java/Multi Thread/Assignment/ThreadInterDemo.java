
public class ThreadInterDemo extends Thread {

	public void run(){
		
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
