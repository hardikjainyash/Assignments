import java.io.*;


class TestEmployee
{

public static void main(String[] args) throws Exception 
{
Employee1 e = new Employee1();
e.setName("Hardik");
e.setDesignation("ASC");
e.setDepartment("Trainee");
e.setSalary(80000);
File f= new File("d:/yash/employee.txt");

ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
oos.writeObject(e);

ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

Employee1 e1=(Employee1)ois.readObject();
System.out.println(e1.getName());
System.out.println(e1.getDesignation());
System.out.println(e1.getDepartment());
System.out.println(e1.getSalary());

oos.close();
ois.close();


}

}