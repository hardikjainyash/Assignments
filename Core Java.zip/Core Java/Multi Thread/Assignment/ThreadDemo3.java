
public class ThreadDemo3 extends Thread {

	public void run()
	{
		System.out.println("Thread Started");
	}
	
	public static void main(String args[]) {
		ThreadDemo3 t3= new ThreadDemo3();
		t3.start();
		ThreadDemo3 td3= new ThreadDemo3();
		td3.start();
	}
	
	
	
	
	
}
