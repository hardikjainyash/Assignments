class ThisDemo2
{
void display()
{
  System.out.println("Yash");
}
void show()
{
  display();
}
public static void main(String []args)
{

ThisDemo2 t2= new ThisDemo2();
t2.show();

}


}