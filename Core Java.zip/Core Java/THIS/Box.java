class Box
{
 int width;int height;int depth;
 Box(int w,int h,int d)
{
this.width=w;
this.height=h;
this.depth=d;


}
int volume()
{

return width*height*depth;

}

public static void main(String []args)
{

Box b= new Box(10,20,30);
System.out.println(b.volume());
}

}