class ThisDemo6
{
public static ThisDemo6 y2()
{
return this;


}
void display()
{
System.out.println("In display");

}
public static void main(String [] args)
{

//ThisDemo6 td6 = new ThisDemo6();
td6=ThisDemo6.y2();
td6.display();
}

}