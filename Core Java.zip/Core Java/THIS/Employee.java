class Employee
{
String s;int id;
Employee()
{
	System.out.println("In default");
	
}
Employee(String s,int id)
{
this.s=s;
this.id=id;

}
public static void main(String args[])
{

Employee e1= new Employee("Yash",101);


System.out.println(e1.s);
System.out.println(e1.id);
Employee e2= new Employee();
}


}