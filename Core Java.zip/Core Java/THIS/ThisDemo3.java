class ThisDemo3
{
ThisDemo3()
{ //this(2);
System.out.println("No Arguments");
}
ThisDemo3(int a)
{
  this();
  System.out.println("with Arguments");
}

public static void main(String []args)
{

ThisDemo3 td5 = new ThisDemo3(12);


}

}