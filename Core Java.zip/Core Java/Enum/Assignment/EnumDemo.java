class EnumDemo
{
enum Directions{
SUN,MON,TUE,WED,THUS,FRI,SAT;}
public static void main(String[] args)
{
  switch(Directions.values().ordinal())
 {
  case 1 : System.out.println("SUN");break;
  case 2 : System.out.println("MON") ;break;
  
  
 }


}



}