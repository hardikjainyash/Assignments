class EnumDemo2
{
 enum Day
 {SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;}
  public static void main(String args[])
  {  Day[] tday=Day.values();
    
	
	for(Day td: tday)
{
  
  switch(td)
  {
   case SUNDAY :
   System.out.println("Today is : "+Day.valueOf("SUNDAY"));
   break;
   
   case MONDAY:
   System.out.println("Today is : "+Day.valueOf("MONDAY"));
   break;
   
   case TUESDAY:
   System.out.println("Today is : "+Day.valueOf("TUESDAY"));
   break;
   
   case WEDNESDAY:
   System.out.println("Today is : "+Day.valueOf("WEDNESDAY"));
   break;
  
   case THURSDAY:
   System.out.println("Today is : "+Day.valueOf("THURSDAY"));
   break;
   
   case FRIDAY:
   System.out.println("Today is : "+Day.valueOf("FRIDAY"));
   break;
   
   case SATURDAY:
   System.out.println("Value of "+Day.valueOf("SATURDAY"));
   break;
   default:
   System.out.println("Invalid");
  } 
  
  }
  
  }
 

}