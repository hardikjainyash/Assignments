import java.util.Scanner;

class VoteEligiblity extends RuntimeException
{

VoteEligiblity(String s)
{
  super(s);
}
}

class ThrowDemo
{

public static void main(String[] args)
{

Scanner s = new Scanner(System.in);
System.out.println("Enter Your Age");
int age=s.nextInt();
try
{

if(age<18)
throw new VoteEligiblity("You are not Eligible"),ArithmeticException;
else 
System.out.println("You are eligible");

}
catch(VoteEligiblity e)
{
e.printStackTrace();
}
System.out.println("Noraml Termination");



}


}