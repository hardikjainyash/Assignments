import java.io.*;
class ExceptionDemo
{

public static void main(String []args)
{
//FileInputStream f = new FileInputStream("D:/xyz.txt");// Checked Exception
try
{
  String s= null;
  System.out.println(s.length());

}
catch(Exception e)
{
System.out.println(e);
}
System.out.println("BYE");

}
}