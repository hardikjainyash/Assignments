import java.util.Scanner;
import java.io.*;

class Exception1
{
public static void main(String[] args)
{ String s1;int a;
Scanner s = new Scanner(System.in);
System.out.println("Enter Integer");
s1=s.next();

try{
a=Integer.parseInt(s1);
System.out.println(a*a);
}
catch(Exception e)
{
	System.out.println("Entered input is not valid");
	
}
}

}