import java.io.IOException;

class ThrowsD
{
	void show() throws IOException
	{
		 System.out.println("Operation performed");
		
	}
	
	
}

class ThrowsDemo1
{
	
	
	public static void main(String args[])
	{
		
		
		ThrowsD t = new ThrowsD();
		
		try
		{
			t.show();
		}
		catch(IOException e)
		{
			e.printStackTrace();
			
		}
		System.out.println("Hello Normal Termination");
		
	}

}