class ClassCast {
   
   
    public static void main(String[] args)
    {
        
           
           
            
            Object o = new Object();
           String S = (Object)o;
       
            System.out.println(S);
			
			}
}