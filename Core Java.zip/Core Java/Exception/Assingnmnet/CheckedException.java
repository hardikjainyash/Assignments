import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.sql.DriverManager;
class CheckedException
{

public static void main(String[] args)
{

try
{

FileInputStream fis = new FileInputStream("d:/yash/hardik.txt");// 1st Exception
String driverName = "oracle.jdbc.driver.OracleDriver";
 
  Class.forName(driverName);
}

catch(FileNotFoundException io)
{
io.printStackTrace();
}
catch(ClassNotFoundException cnf)
{
	cnf.printStackTrace();
	
}

}




}