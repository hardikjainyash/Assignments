class A 
{

static void show()
{
System.out.print("In A");

}

}
 
 
 class B extends A
 {
 void show()
 {
 System.out.print("In B");
 }
 
 }
 class CMulti extends B
{

public static void main(String args[])
{
	
	show();
	
	
}

}