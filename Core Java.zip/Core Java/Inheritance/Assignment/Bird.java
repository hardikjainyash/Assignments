class Animal
{
void eat()
{
System.out.println("In Parent Eat");
}
void sleep()
{
System.out.println("In Parent Sleep");
}


}

class Bird extends Animal
{
void eat()
{
System.out.println("In Child Eat");
}
void sleep()
{
System.out.println("In Child Sleep");
}
void fly()
{
System.out.println("In Child Fly");

}

public static void main(String[] args)
{

Animal A = new Animal();
A.eat();
A.sleep();
Bird B = new Bird();
B.eat();
B.sleep();
B.fly();
}
}
