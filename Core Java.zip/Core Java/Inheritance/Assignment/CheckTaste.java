class Fruit
{
String Name;
String taste;
String size;
void eat()
{
Name="Mango";
taste="Sweet";


}


}


class Apple extends Fruit
{
	
void eat()
{
taste="Little Sweet";
System.out.println(taste);
}
	


}

class Orange extends Fruit
{

      void eat()
    {
     taste="Soar";
     System.out.println(taste);
     }
	



}

class CheckTaste
{

public static void main(String[] args)
{

Apple A = new Apple();
Orange O = new Orange();
A.eat();
O.eat();
}


}