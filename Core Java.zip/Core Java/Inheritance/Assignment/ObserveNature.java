class Shape
{
void draw()
{
System.out.println("Drawing Shape");
}

void erase()
{
System.out.println("Erasing Shape");
}
}

class Circle extends Shape
{
void draw()
{
System.out.println("Drawing Circle");
}

void erase()
{
System.out.println("Erasing Circle");
}
}


class Triangle extends Shape
{
void draw()
{
System.out.println("Drawing Triangle");
}

void erase()
{
System.out.println("Erasing Triangle");
}

}


class Square extends Shape
{
void draw()
{
System.out.println("Drawing Square");
}

void erase()
{
System.out.println("Erasing Square");
}


}

class ObserveNature
{
public static void main(String[] args)
{
Shape C = new Circle();
Shape T = new Triangle();
Shape S = new Square();
C.draw();
C.erase();
T.draw();
T.erase();
S.draw();
S.erase();



}

}