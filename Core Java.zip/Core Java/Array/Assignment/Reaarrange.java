class Reaarrange {
 public static void main(String [] args)
{ int swap=0;

int a[] = {45,3,6,40};
int len=a.length;
for(int i=0;i<len;i++)
 {
    for(int j=len-1;j>=i;j--)
   {
      if(a[i]%2!=0 && a[j]%2==0)
	  {
	    swap=a[j];
        a[j]=a[i];
        a[i]=swap;
	  }
     
   
   } 
 
 }

for(int i=0;i<len;i++)
  System.out.println(a[i]);



}





}