class PresentNum{
public static void main(String args[])
{  int f=0;
int a=Integer.parseInt(args[0]);
int[] ar ={20,30,10,12,50};
for(int i=0;i<ar.length;i++)
{
  if(ar[i]==a)
   { System.out.println(i);
	f=1;
}

}
if(f==0)
System.out.println("-1");
}


}