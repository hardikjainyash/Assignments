class ReverseTwoD{
public static void main(String args[])
{int count=0;
 int ar[][] = new int[2][2];
for(int i=0;i<2;i++)
{
   for(int j=0;j<2;j++)
   {  
          ar[i][j]=Integer.parseInt(args[count]);
		  ++count;
   }
}

for(int i=0;i<2;i++)
{ System.out.println();
   for(int j=0;j<2;j++)
   {  
          System.out.print(ar[i][j]+" ");
   }
}
System.out.println("Reverse is-");

for(int i=1;i>=0;i--)
{ System.out.println();
   for(int j=1;j>=0;j--)
   {  
          System.out.print(ar[i][j]+" ");
   }
}




}



}