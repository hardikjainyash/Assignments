class SortInAscending{

public static void main(String args[])
{int swap=0;
int[] ar ={20,30,10,12,50};
for(int i=0;i<ar.length;i++)
 {
 for(int j=i+1;j<ar.length-1;j++)
{
 if(ar[i]>ar[j])
 { swap=ar[j];
  ar[j]=ar[i];
  ar[i]=swap;
}

} 
 
 }
 
for(int i=0;i<ar.length;i++)
 System.out.print(ar[i]+" ");



}

}