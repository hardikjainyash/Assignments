class SecondMaxmin{
public static void main(String []args)
{ int max=0;
int max1=0;
  int el=0;
  int e=0;
int[] a ={20,30,10,12,50};
int min=a[0];
int min1=a[0];

for(int i=0;i<a.length;i++)
{
 if(a[i]>max)
  { max=a[i];
   el=i;
   }
 if(a[i]<min)
  {  min=a[i];
    e=i;
  }
 }
System.out.println("First Maximum is"+max);
System.out.println("First Minimum is"+min);

for(int i=0;i<a.length;i++)
{
 if(i!=el)
  {   if(a[i]>max1)
      max1=a[i];
 
   }
   
   if(i!=e)
   {
     if(a[i]<min1)
       min1=a[i];
   }
   
}

System.out.println("Second Maximum is"+max1);
System.out.println("Second Minimum is"+min1);



}



}