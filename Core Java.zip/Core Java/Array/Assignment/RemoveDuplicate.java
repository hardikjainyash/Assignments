class RemoveDuplicate{

public static void main(String args[])
{ int re=0;
int[] a ={2,3,3,3};
int ind[] = new int[a.length];
for(int i=0;i<a.length;i++)
 {
   for(int j=i+1;j<a.length;j++)
    {
	  if(a[i]==a[j])
	    a[j]=-1;
	} 
 
 
 }
 for(int i=0;i<a.length;i++)
{
  if(a[i]!=-1)
    System.out.println(a[i]);
 }


//for(int i=0;i<ind.length;i++)
 // System.out.println(ind[i]);
}



}