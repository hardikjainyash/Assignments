class JaggedArray{
public static void main(String args[])
{
int [][]a = new int[3][];
a[0]= new int[3];
a[1]= new int[2];
a[2]= new int[3];																
System.out.println(a);
System.out.println(a[0]);
System.out.println(a[0][0]);
System.out.println(a.length);
//System.out.println(a[0][0].length);
}

}