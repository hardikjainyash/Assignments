class BigInTwoD{
public static void main(String args[])
{
int count=0;
 int ar[][] = new int[3][3];
for(int i=0;i<3;i++)
{
   for(int j=0;j<3;j++)
   {  
          ar[i][j]=Integer.parseInt(args[count]);
		  count++;
   }
}
if(count<=9)
System.out.print("Please enter 9 variable");




}


}