class Average{
public static void main(String args[])
{ int total=0;
int a[]= new int[]{10,20,30,40};
for(int i=0;i<a.length;i++)
 total=total+a[i];
System.out.println("Sum is-"+total);
System.out.println("Averageis -"+total/4);

}

}