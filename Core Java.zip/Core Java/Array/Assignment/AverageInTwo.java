class AverageInTwo{
public static void main(String args[])
{ int total=0;
int[][] a =new int[][]{{10,20},{30,40,50}};
for(int i=0;i<a.length;i++)
 {
 for(int j=0;j<a[i].length;j++){
 total=total+a[i][j]; 
 
 }
 
 }
System.out.println("Sum is-"+total);
System.out.println("Sum is-"+total/5);


}



}