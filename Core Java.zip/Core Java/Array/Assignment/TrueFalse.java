class TrueFalse{
public static void main(String []args)
{ int count=0;
int f=0;
int[] a ={1,4,4,1};
for(int i=0;i<a.length;i++)
 {
 if(a[i]==4 || a[i]==1)
 { count++;
   continue;

 }
 else 
 { System.out.print("False"); 
     break;
 }
 
 
 
 }
 
 	 if(count==a.length)
      System.out.print("True");
}



}