abstract class Vehicle
{
abstract void start();
}

abstract class Car extends Vehicle
{

abstract void Accelration();

}

class Scooter extends Car
{
//void start()
//{
//System.out.println("Starts with kick");
//}

void Accelration()
{
System.out.println("In Accelration");
}

public static void main(String[] args)
{
Scooter S = new Scooter();
S.Accelration();
}

}