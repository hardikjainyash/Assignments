abstract class Parent
{
abstract void salary();
}

class Son1 extends Parent
{
  void salary()
 {
System.out.println("Salary is 10000");
}


}

class Son2 extends Parent
{
void salary()
{
System.out.println("Salary is 20000");
}

public static void main(String[] args)
{
Son1 S1 = new Son1();
S1.salary();
Son2 S2 = new Son2();
S2.salary();
}

}