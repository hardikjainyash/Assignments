interface Balance
{
  void user1();

}


class C{
	
	void displau()
	{
		
		
	}
	
}

interface Withdraw implements C
{

void user2();
}



class Bank implements Balance,Withdraw
{

public void user1()
{
System.out.println("Balance is 300");
}
public void user2()
{
System.out.println("300 is withdraw");
}

public static void main(String [] args)
{
Bank B =new Bank();
B.user1();
B.user2();

}
}