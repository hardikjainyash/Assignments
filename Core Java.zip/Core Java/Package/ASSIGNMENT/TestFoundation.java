import testpackage.Foundation;

class TestFoundation
{

public static void main(String[] args)
{

Foundation f = new Foundation();
System.out.println("Public data"+f.var3);
//System.out.println("Private data"+f.var1);
//System.out.println("Protecteddata"+f.var4);
System.out.println("default data"+f.var2);


}


}