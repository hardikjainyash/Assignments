package testpackage;

public class Foundation
{

private int var1=10;
int var2=12;
public int var3=13;
protected int var4=17;



}