package traineepackage;

public class Student
{
 
 public void enterName(String Name)
 {
   System.out.println(Name);
 
 
 }




}