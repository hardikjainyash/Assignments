import traineepackage.Student;

class EnterName
{

public static void main(String []args)
{

Student S = new Student();
S.enterName("Vijay");

}

}