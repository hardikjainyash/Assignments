import java.io.*;
class ByteArrayOutputDemo
{

public static void main(String[] args) throws IOException
{

FileOutputStream f1 = new FileOutputStream("d:/yash/abc.txt");
FileOutputStream f2 = new FileOutputStream("d:/yash/xyz.txt");
ByteArrayOutputStream b1 = new ByteArrayOutputStream();

b1.write(65);//holds te data
b1.writeTo(f1);//and then write into output stream;
b1.writeTo(f2);
b1.close();
f1.close();



}




}