import java.io.*;


class TestEmployee2
{

public static void main(String[] args) throws Exception 
{
Employee2 e = new Employee2("Hardik","Trainee","ASC",80000);
File f= new File("d:/yash/employee.txt");

ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
oos.writeObject(e);

ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

Employee2 e2 =(Employee2)ois.readObject();
System.out.print(e2);




}
}