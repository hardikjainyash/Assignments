import java.io.FileOutputStream;
import java.io.BufferedOutputStream;

class BufferedOutputDemo
{
public static void main(String[] args)
{
String str = "Hardik";
  
  byte[] b = str.getBytes();
try
{
FileOutputStream fos = new FileOutputStream("d:/yash/abc.txt");
BufferedOutputStream bos =new BufferedOutputStream(fos);
bos.write(b);

bos.close();
fos.close();
}
catch(Exception e)
{
e.printStackTrace();
}



}



}