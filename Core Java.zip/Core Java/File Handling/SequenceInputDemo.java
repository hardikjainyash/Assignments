import java.io.*;

class SequenceInputDemo
{

public static void main(String[] args) throws Exception
{
FileInputStream f1 = new FileInputStream("d:/yash/abc.txt");
FileInputStream f2 = new FileInputStream("d:/yash/xyz.txt");
FileOutputStream fos = new FileOutputStream("d:/yash/append.txt");
SequenceInputStream st = new SequenceInputStream(f1,f2);
int i;
while((i=st.read())!=-1)
fos.write(i);
st.close();
fos.close();
f1.close();
f2.close();

}





}