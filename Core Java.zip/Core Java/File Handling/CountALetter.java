import java.io.IOException;
import java.io.FileInputStream;
import java.util.Scanner;
import java.io.File;

class CountALetter
{

public static void main(String[] args) throws Exception
{
Scanner s = new Scanner(System.in);
System.out.println("Enter the file name");
String f=s.next();
File file= new File(f);

FileInputStream f1 = new FileInputStream(f);
System.out.println("Enter the character to be counted");

char ch=s.next().charAt(0);
int i;
int count=0;
while((i=f1.read())!=-1)
{
if(i==(int)ch)
 count++;
if(i-(int)ch==32 || i-(int)ch==-32)
	count++;

}

System.out.println("File "+f+" has "+count+" instances of "+ch);
f1.close();
}



}