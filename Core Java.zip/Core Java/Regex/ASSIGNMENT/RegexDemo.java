import java.util.regex.Pattern;
import java.util.regex.Matcher;
class RegexDemo
{
	public static void main(String args[])
	{
		String s="^\\d{10}$";
		String[] a={"8989989894","789998","yh899999999999"};
		for(String i:a)
		{
			System.out.println(i+":"+i.matches(s));
		}
			
		String t="^[a-zA-Z0-9]+@[a-zA-Z0-9.]+$";
		String[] b={"yuktanagle025@gmail.com","abc@yahoo.com"};
		for(String j:b)
		{
			System.out.println(j+":"+j.matches(t));
		}

		String u="^(https://)(www.)([a-zA-Z0-9.])+([a-z]{3})$";
		String[] c={"https://www.example.com","http://www.google.com"};
		for(String k:c)
		{
			System.out.println(k+":"+k.matches(u));
		}
		
		String v="[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}";
		String[] d={"11/04/2022"};
		for(String l:d)
		{
			System.out.println(l+":"+l.matches(v));
		}
		
		}
	}
