class CheckNum{
public static void main(String []args){

if(Integer.parseInt(args[0])>0)
 System.out.print("first is Positive");
else 
 System.out.println("First is Negative");
if(Integer.parseInt(args[1])>0)
 System.out.print("Second is Positive");
else 
 System.out.println("Second is Negative");

}


}

