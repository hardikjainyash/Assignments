class Factorial{
public static void main(String args[]){

int a=Integer.parseInt(args[0]);
int ans=1;
for(int i=a;i>0;i--)
{  
   ans =ans*a;
   --a;
}
System.out.println(ans);
}

}