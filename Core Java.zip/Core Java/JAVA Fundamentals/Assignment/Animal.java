class Animal{

static String s;
int a;


public static void main(String args[])
{
s="Hard";
System.out.println(s);



}


}