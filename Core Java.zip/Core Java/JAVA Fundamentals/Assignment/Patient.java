class Patient
{
String patientName; double height;
double weight;

Patient(double h,double w)
{
this.height=h;
this.weight=w;
}

double computeBMI()
{
return weight/height*height;


}

public static void main (String[] args)
{

Patient Pat= new Patient(2,50);
System.out.println(Pat.computeBMI());

}
}