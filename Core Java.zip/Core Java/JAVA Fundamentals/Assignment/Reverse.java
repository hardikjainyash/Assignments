class Reverse{

public static void main(String args[])
{

int a=Integer.parseInt(args[0]);
int ans=1;int c=1;
while(a!=0)
{
c=a%10;

ans=c*10+a;
a=a/10;
}
System.out.println(ans);

}

}