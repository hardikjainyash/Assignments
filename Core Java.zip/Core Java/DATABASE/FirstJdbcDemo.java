import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;

public class FirstJdbcDemo
{

public static void main(String[] args)
{

try
{

Class.forName("com.mysql.jdbc.Driver");

String url ="jdbc:mysql://localhost:3306/hardik";
String user="root";
String pass="root";

Connection con =DriverManager.getConnection(url,user,pass);
if(con!=null)
System.out.println("Connection is Created");
else
System.out.println("Connection is Not Created");

String q ="select name from employee where empId=?";
//double id;
//String name,contactnum;

PreparedStatement ps = con.prepareStatement(q);

ps.setInt(1, 101);
ResultSet rs =ps.executeQuery();
while(rs.next())
{    
System.out.println(rs.getString("name"));
}

	
con.close();

}

catch(Exception e)
{
  System.out.println(e);
}
}



}
