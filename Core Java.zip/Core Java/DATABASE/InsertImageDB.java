import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.cj.jdbc.Blob;

public class InsertImageDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");

			String url ="jdbc:mysql://localhost:3306/hardik";
			String user="root";
			String pass="root";

			Connection con =DriverManager.getConnection(url,user,pass);
			if(con!=null)
			System.out.println("Connection is Created");
			else
			System.out.println("Connection is Not Created");
			PreparedStatement ps=con.prepareStatement("insert into imageinsert values(?,?)");  
			ps.setString(1,"This is Image");  
			  
			FileInputStream fin=new FileInputStream("d:\\download.jfif");  
			ps.setBinaryStream(2,fin,fin.available());  
			int i=ps.executeUpdate();  
			System.out.println(i+" records affected");  
			System.out.println("Image is inserted");
			
			
			PreparedStatement ps1=con.prepareStatement("select * from imageinsert");  
			ResultSet rs=ps1.executeQuery();  
			if(rs.next()){//now on 1st row  
			              
			Blob b=(Blob) rs.getBlob(2);//2 means 2nd column data  
			byte barr[]=b.getBytes(1,(int)b.length());//1 means first image  
			              
			FileOutputStream fout=new FileOutputStream("d:\\ImageFromDb.jpg");  
			fout.write(barr);  
			System.out.println("Image is extract from DB");              
			fout.close();  
			}      
			con.close();  
			fin.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
